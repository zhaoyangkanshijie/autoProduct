/**
 * @license Copyright (c) 2009-2013, xhEditor.com. All rights reserved.
 * For licensing, see LGPL-LICENSE.txt or http://xheditor.com/license/lgpl.txt
 */
(function(){

    var XHEDITOR = {};
    window.XHEDITOR = XHEDITOR;

})();